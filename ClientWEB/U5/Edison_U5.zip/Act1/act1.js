for (let i = 0; i < 10000; i++) {
    if(i%2 == 0){
        document.write(i + " - odd<br>");
    }else{
        document.write(i + "- even<br>");
    }
}
