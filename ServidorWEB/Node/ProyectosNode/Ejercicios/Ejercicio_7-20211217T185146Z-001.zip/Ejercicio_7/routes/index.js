const express = require('express');

let router = express.Router();

// Definir las rutas aquí

module.exports = router