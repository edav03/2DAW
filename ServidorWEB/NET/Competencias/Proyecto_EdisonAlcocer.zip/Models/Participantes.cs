﻿namespace Competencias.Models
{
    public class Participantes
    {
        public int IdParticipantes { get; set; }
        public int NumCarrera { get; set; }
        public int Dorsal { get; set; }
        public string Apellidos { get; set; }
        public string Nombre { get; set; }
        public string Dni { get; set; }
        public string Club { get; set; }
        public int PosicionGeneral { get; set; }
        public string TiempoOficial { get; set; }

    }
}
