﻿namespace Competencias.Models
{
    public class CodigoChips
    {
        public string Codigo { get; set; }
        public int Dorsal { get; set; }
    }
}
