﻿namespace Competencias.Models
{
    public class Carrera
    {
        public int IdCarrera { get; set; }
        public int NumCarrera { get; set; }
        public string DescripcionCarrera { get; set; }
        public string FechaCarrera { get; set; }
        public string Distanciaenmetros { get; set; }
        public string HoraInicio { get; set; }
    }
}
