@extends('plantilla')

@section('titulo', 'Probando Laravel')

@section('contenido')
    <h1>Contenido de la pagina</h1>
@endsection