<nav>
    <h3><a href="{{ route('inicio') }}">Pagina de inicio</a></h3>
    <h3><a href="{{ route('posts_listado')}}">Listado de posts</a></h3>
</nav>