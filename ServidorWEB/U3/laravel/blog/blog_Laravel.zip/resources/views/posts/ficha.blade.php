@extends('plantilla')

@section('titulo', 'Ficha post')

@section('contenido')
    <h1>Ficha posts {{ $id }}</h1>
@endsection