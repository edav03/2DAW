<html>
    <head>
        <title>
            <?php echo $__env->yieldContent('titulo'); ?>
        </title>
        
    </head>
    <body>
        <?php echo $__env->yieldContent('contenido'); ?>
    </body>
</html>
<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edison/Documents/2DAW/ServidorWEB/U3/laravel/blog/resources/views/plantilla.blade.php ENDPATH**/ ?>