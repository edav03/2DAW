<?php $__env->startSection('titulo', 'Probando Laravel'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Contenido de la pagina</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edison/Documents/2DAW/ServidorWEB/U3/laravel/blog/resources/views/inicio.blade.php ENDPATH**/ ?>