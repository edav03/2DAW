<nav>
    <h3><a href="<?php echo e(route('inicio')); ?>">Pagina de inicio</a></h3>
    <h3><a href="<?php echo e(route('posts_listado')); ?>">Listado de posts</a></h3>
</nav><?php /**PATH /home/edison/Documents/2DAW/ServidorWEB/U3/laravel/blog/resources/views/partials/nav.blade.php ENDPATH**/ ?>