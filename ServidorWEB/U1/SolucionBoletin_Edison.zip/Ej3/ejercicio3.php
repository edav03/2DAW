<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $primera = 10;
            $segunda = 2;

            echo "La diferencia entre 10 y 2 es ". $primera - $segunda;

            echo "<br>";

            echo "La division entre 10 y 2 es ". $primera / $segunda;
        ?>
    </body>
</html>