<?php
for ($i=1; $i < 101 ; $i++) { 
    echo $i . ", ";
}