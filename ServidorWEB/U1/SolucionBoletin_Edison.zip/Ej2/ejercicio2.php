<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $primera = 4;
            $segunda = 8;

            echo "La suma entre 4 y 8 es ". $primera + $segunda;

            echo nl2br("\n\nEl producto entre 4 y 8 es ". $primera * $segunda);
        ?>
    </body>
</html>