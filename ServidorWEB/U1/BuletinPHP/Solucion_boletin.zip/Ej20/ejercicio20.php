<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Figura</title>
    </head>
    <body>
        <?php

            for ($i=0; $i <= 6; $i++) { 
                
                for ($j=0; $j < $i; $j++) { 
                    echo "*";
                }

                echo "<br>";
            }

        ?>
    </body>
</html> 