<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $primera = 4;
            $segunda = 8;

            echo "4 elevado a 8 es ". pow(4, 8) . "<br>";

            echo "La raiz cuadrada de 4 es ". sqrt(4). "<br>";
            
            echo "La raiz cuadrada de 8 es ". sqrt(8). "<br>";
        ?>
    </body>
</html>