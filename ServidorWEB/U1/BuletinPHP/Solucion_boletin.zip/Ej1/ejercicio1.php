<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
        echo "Esta es la primera práctica escrita en PHP";
        ?>

        <p>Escrita por Alcocer Valencia, Edison David</p>
    </body>
</html>