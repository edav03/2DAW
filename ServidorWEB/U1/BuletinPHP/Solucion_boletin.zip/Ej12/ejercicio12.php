<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $number = 100;

            while ($number > -1) {
                echo $number . ", ";

                $number -=2;
            }
        ?>
    </body>
</html>