<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $number = 1;
            while($number < 101){
                echo $number . ", ";
                $number++;
            }
        ?>
    </body>
</html>